"""
# Projet Wall Is You - Tâche 4
# Interface graphique pour Wall Is You (utilise `fltk.py` existant).
# Auteur : Lohan, Daniel
# Date : 9 janvier 2026

Ce fichier affiche une grille carrée centrée, dessine des murs et des
ouvertures pour chaque salle (visible lors des rotations), et place
l'aventurier et les dragons au centre des cases.
"""
import os
import moteur
import fltk
import chargement_donjon

# Variables globales
nb_lignes = 6
nb_colonnes = 8
nb_dragons = 5
nb_bonus = 1
graine_donjon = None
largeur_fenetre = 1000
hauteur_fenetre = 700
marge = 40
marge_droite = 200
taille_case = 0
grille_x0 = 0
grille_y0 = 0
donjon = None
aventurier = None
dragons = None
bonus = None
tresor = []
compteur_tresors = 4
intention = []
indice = None
donjon_indice = None



def obtenir_texture_etat(etat):
    """
    Retourne le fichier texture correspondant à l'état d'une salle.
    Paramètres : haut, droite, bas, gauche (booléens)
    """
    haut, droite, bas, gauche = etat

    # --- Couloirs ---
    if haut and not droite and bas and not gauche:
        return 'texture/nord-sud.png'
    if not haut and droite and not bas and gauche:
        return 'texture/ouest-est.png'

    # --- Coins ---
    if haut and droite and not bas and not gauche:
        return 'texture/nord-est.png'
    if not haut and droite and bas and not gauche:
        return 'texture/sud-est.png'
    if not haut and not droite and bas and gauche:
        return 'texture/ouest-sud.png'
    if haut and not droite and not bas and gauche:
        return 'texture/nord-ouest.png'

    # --- Culs-de-sac ---
    if haut and not droite and not bas and not gauche:
        return 'texture/nord.png'
    if not haut and droite and not bas and not gauche:
        return 'texture/est.png'
    if not haut and not droite and bas and not gauche:
        return 'texture/sud.png'
    if not haut and not droite and not bas and gauche:
        return 'texture/ouest.png'

    # --- Trois ouvertures ---
    if haut and droite and bas and not gauche:
        return 'texture/nord-est-sud.png'
    if not haut and droite and bas and gauche:
        return 'texture/est-sud-ouest.png'
    if haut and not droite and bas and gauche:
        return 'texture/nord-sud-ouest.png'
    if haut and droite and not bas and gauche:
        return 'texture/nord-est-ouest.png'
    # --- Quatre ouvertures ---
    if haut and droite and bas and gauche:
        return 'texture/nord-est-sud-ouest.png'
    return None

def mettre_a_jour_taille_case():
    """
    Calcule la taille des cases et la position de la grille
    en fonction de la taille de la fenêtre.
    """
    global taille_case, grille_x0, grille_y0
    largeur_grille = largeur_fenetre - 2 * marge - marge_droite
    hauteur_grille = hauteur_fenetre - 2 * marge
    largeur_case = largeur_grille // nb_colonnes
    hauteur_case = hauteur_grille // nb_lignes
    taille_case = max(8, min(largeur_case, hauteur_case))
    largeur_totale = taille_case * nb_colonnes
    hauteur_totale = taille_case * nb_lignes
    grille_x0 = marge + (largeur_grille - largeur_totale) // 2
    grille_y0 = marge + (hauteur_grille - hauteur_totale) // 2

def obtenir_case_de_xy(x, y):
    """
    Convertit des coordonnées (x,y) en indices de case (i,j).
    Retourne la case correspondante dans la grille.
    """
    j = (x - grille_x0) // taille_case
    i = (y - grille_y0) // taille_case
    i = int(max(0, min(nb_lignes - 1, i)))
    j = int(max(0, min(nb_colonnes - 1, j)))
    return (i, j)

def centre_de_case(case):
    """
    Retourne les coordonnées du centre d'une case (i,j).
    """
    i, j = case
    cx = grille_x0 + j * taille_case + taille_case // 2
    cy = grille_y0 + i * taille_case + taille_case // 2
    return cx, cy

def afficher_commandes():
    """
    Affiche la liste des commandes disponibles sur le côté droit de l'écran.
    """
    global compteur_tresors
    x = largeur_fenetre - marge_droite + 20
    y = 60
    espacement = 30

    commandes = [
        ("Commandes:", "red", 14),
        ("", "black", 12),
        ("Clic gauche", "cyan", 12),
        ("→ Pivoter une salle", "red", 12),
        ("Espace", "cyan", 12),
        ("→ Valider intention", "red", 12),
        ("R", "cyan", 12),
        ("→ Nouvelle partie", "red", 12),
        ("Échap", "cyan", 12),
        ("→ Quitter", "red", 12),
        ("S", "cyan", 12),
        ("→ Sauvegarder partie", "red", 12),
        ("L", "cyan", 12),
        ("→ Charger sauvegarde", "red", 12),
        ("i", "cyan", 12),
        ("→ Indice", "red", 12),
    ]

    for texte, couleur, taille in commandes:
        fltk.texte(x, y, texte, couleur=couleur, ancrage='w', taille=taille)
        y += espacement

    # affichage du nombre de trésor disponible
    y += 40

    fltk.texte(
        x, y, 
        "Trésors restants :",
        couleur="yellow",
        ancrage='w',
        taille=12
    )
    

    # Icône du trésor
    fltk.image(
        x -20, y + 0,
        "texture/tresor.png",
        largeur=30,
        hauteur=30,
        ancrage="center"
    )

    # Nombre de trésors
    fltk.texte(
        x + 130, y + 0,
        str(compteur_tresors),
        couleur="cyan",
        ancrage="center",
        taille=12
    )

def dessiner_statistiques():
    """
    Affiche le niveau de l'aventurier et le nombre de trésors 
    sous la grille du donjon.
    """
    global aventurier, compteur_tresors, grille_y0, nb_lignes, taille_case
    
    # Calcul de la position Y : juste en dessous de la dernière ligne du donjon
    y_stats = grille_y0 + (nb_lignes * taille_case) + 20
    x_centre = largeur_fenetre // 2.5
    
    # Texte du niveau
    niveau = aventurier[1]
    message = "Niveau de l'aventurier : " + str(niveau)
    fltk.rectangle(x_centre - 105, y_stats - 15, x_centre + 105, y_stats + 15, 
                   couleur="black", remplissage="darkgrey", epaisseur=1)
    
    # Affichage du texte
    fltk.texte(x_centre, y_stats, message, 
               couleur="black", ancrage="center", taille=14)

def rafraichir_affichage():
    """
    Redessine l'intégralité de l'interface :
    - Donjon (salles avec textures)
    - Aventurier et dragons
    - Intention (chemin en rouge)
    - Commandes et niveau du héros
    - Bonus et Trésor
    - Indice
    """
    #print("NB TRESORS =", len(moteur.tresor))
    fltk.efface_tout()
    niveau_aventurier = aventurier[1]
    fltk.texte(largeur_fenetre // 2, hauteur_fenetre - 30,
               "Niveau de l'aventurier : " + str(niveau_aventurier),ancrage="center", taille=18, couleur="blue")
    fltk.rectangle(0, 0, largeur_fenetre, hauteur_fenetre,remplissage="gray10", couleur="gray10")
    dessiner_statistiques()

    afficher_commandes()

    # Bordure du donjon
    largeur_donjon = taille_case * nb_colonnes
    hauteur_donjon = taille_case * nb_lignes
    epaisseur_bordure = 6
    x0 = grille_x0 - epaisseur_bordure
    y0 = grille_y0 - epaisseur_bordure
    x1 = grille_x0 + largeur_donjon + epaisseur_bordure
    y1 = grille_y0 + hauteur_donjon + epaisseur_bordure
    fltk.rectangle(x0, y0, x1, y1, remplissage="black", couleur="black")

    # Salles
    for i in range(nb_lignes):
        for j in range(nb_colonnes):
            x0 = grille_x0 + j * taille_case
            y0 = grille_y0 + i * taille_case
            x1 = grille_x0 + (j + 1) * taille_case
            y1 = grille_y0 + (i + 1) * taille_case
            cx = (x0 + x1) // 2
            cy = (y0 + y1) // 2

            etat_salle = donjon[i][j]
            nom_image = obtenir_texture_etat(etat_salle)

            # Test de sécurité si le donjon n'est pas encore initialisé (ne devrait pas arriver ici)
            if donjon is None: 
                 fltk.rectangle(x0, y0, x1, y1, remplissage='red', couleur='black')
                 continue

            # Récupérer l'état de la salle (ex: (True, True, False, False))
            etat_salle = donjon[i][j]

            # Choisir le bon fichier image grâce au dictionnaire
            nom_image = obtenir_texture_etat(etat_salle)

            # Si on a trouvé une image pour cet état, on l'affiche
            if nom_image:
                try:
                    fltk.image(cx, cy,nom_image,largeur=(x1 - x0), hauteur=(y1 - y0), ancrage='center')
                except Exception as e:
                    # En cas d'erreur (ex: image manquante ou format illisible), dessiner un carré ROSE
                    print("Erreur image", nom_image, ":", e)
                    fltk.rectangle(x0, y0, x1, y1, remplissage='pink', couleur='pink')
            else:
                # Si l'état n'est pas dans le dico

                # CAS 1: L'état est une salle fermée (0 passage)
                if etat_salle == (False, False, False, False):
                    # Dessiner un mur plein de couleur jaune
                    fltk.rectangle(x0, y0, x1, y1, remplissage='yellow', couleur='black')
                
                # CAS 2: L'état est un type de salle inconnu (ex: 3 ou 4 passages)
                else:
                    # Afficher en gris pour signaler un état non répertorié
                    print(f"DEBUG: État de salle inconnu en ({i}, {j}): {etat_salle}. Affiché en gris.")
                    fltk.rectangle(x0, y0, x1, y1, remplissage='grey', couleur='black')

    # Dragons
    for pos, niveau in dragons:
        cx, cy = centre_de_case(pos)


        fltk.image(cx, cy, "texture/dragon.png",
                largeur=int(taille_case*0.6),
                hauteur=int(taille_case*0.6),
                ancrage="center")


        box_w = int(taille_case * 0.30)
        box_h = int(taille_case * 0.20)
        x_box = cx + int(taille_case * 0.20)
        y_box = cy - int(taille_case * 0.20)
        x0 = x_box - box_w // 4
        y0 = y_box - box_h // 2
        x1 = x_box + box_w // 4
        y1 = y_box + box_h // 2
        fltk.rectangle(x0, y0, x1, y1,
                    remplissage="white",
                    couleur="black")
        fltk.texte(x_box, y_box, str(niveau),
                couleur="blue",
                ancrage="center",
                taille=int(taille_case * 0.13))

    # Aventurier
    pos_x, pos_y = centre_de_case(aventurier[0])
    fltk.image(pos_x, pos_y, "texture/aventurier.png",
               largeur=int(taille_case * 0.6),
               hauteur=int(taille_case * 0.6),
               ancrage='center')
    
    # Bonus
    global bonus
    if bonus:
        for pos in bonus:
            cx, cy = centre_de_case(pos)
            fltk.image(cx, cy, "texture/bonus.png",
                       largeur=int(taille_case * 0.3),
                       hauteur=int(taille_case * 0.3),
                       ancrage='center')
            
    # Trésors
    for pos in moteur.tresor:
        print("AFFICHAGE TRESOR =", pos)
        cx, cy = centre_de_case(pos)
        fltk.image(cx, cy, "texture/tresor.png",
                largeur=int(taille_case * 0.4),
                hauteur=int(taille_case * 0.4),
                ancrage='center')




    # Indice (chemin en bleu clair)
    global indice
    if indice:
        points = [centre_de_case(indice[0])]
        for case in indice[1:]:
            points.append(centre_de_case(case))
        for i in range(len(points) - 1):
            fltk.ligne(points[i][0], points[i][1],
                       points[i+1][0], points[i+1][1],
                       couleur="cyan", epaisseur=1)
    
    # Intention (chemin en rouge)
    global intention
    intention = moteur.intention(donjon, aventurier[0], dragons)
    if intention:
        points = [centre_de_case(intention[0])]
        for case in intention[1:]:
            points.append(centre_de_case(case))
        for i in range(len(points) - 1):
            fltk.ligne(points[i][0], points[i][1],
                       points[i+1][0], points[i+1][1],
                       couleur="red", epaisseur=3)

    fltk.mise_a_jour()

def pivoter_case(case):
    """
    Fait pivoter la salle sélectionnée et rafraîchit l'affichage.
    """
    i, j = case
    moteur.faire_pivoter_donjon(donjon, i, j)
    rafraichir_affichage()

def effacer_intention():
    """
    Réinitialise le chemin d'intention (liste vide).
    Rafraîchit l'affichage pour supprimer le tracé rouge.
    """
    global intention
    intention = []
    rafraichir_affichage()

def appliquer_intention():
    """
    Applique le chemin d'intention de l'aventurier.
    """
    global aventurier, dragons, compteur_tresors
    
    if not intention:
        return

    chemin = list(intention)
    if chemin[0] != aventurier[0]:
        chemin = [aventurier[0]] + chemin

    pos_depart = list(aventurier[0])

    # APPEL AU MOTEUR
    resultat = moteur.appliquer_tour_aventurier(donjon, aventurier, dragons, chemin)
    statut, message, msg_combat = resultat[0], resultat[1], resultat[4]
    
    aventurier[0] = pos_depart

    if statut == "defaite":
        print("Défaite !", message)
        fltk.texte(largeur_fenetre // 2, 20, message, couleur="red", ancrage="center", taille=20)
        fltk.mise_a_jour()
        fltk.attente(2)
        retour_menu()
        return

    # Animation si l’aventurier est vivant (en cours, victoire OU TRESOR)
    if statut in ("en_cours", "victoire", "tresor"):
        chemin_restant = chemin[1:]
        
        for position in chemin_restant:
            aventurier[0] = list(position)

            # GESTION DES BONUS
            for b in bonus[:]:
                if b == aventurier[0]:
                    bonus.remove(b)
                    aventurier[1] += 1
            
            # GESTION DES TRESORS
            if aventurier[0] in moteur.tresor:
                moteur.tresor.remove(aventurier[0]) 
                print("Trésor récupéré !")
                
            # GESTION DES COMBATS
            for d in dragons[:]:
                if d[0] == aventurier[0]:
                    if aventurier[1] >= d[1]:
                        dragons.remove(d)
                        aventurier[1] += 1
                        print("Dragon vaincu ! Il en reste", len(dragons))
                        if len(dragons) == 0:
                            rafraichir_affichage() # Pour voir le dernier dragon disparaître
                            fltk.texte(largeur_fenetre // 2, 20, "PLUS DE DRAGONS : VICTOIRE !", 
                                       couleur="green", ancrage="center", taille=20)
                            fltk.mise_a_jour()
                            fltk.attente(2)
                            retour_menu() # On retourne au menu
                            return
                    else:
                        fltk.texte(largeur_fenetre // 2, 20, "Défaite !",
                                couleur="red", ancrage="center", taille=20)
                        fltk.mise_a_jour()
                        fltk.attente(2)
                        fltk.ferme_fenetre() 
                        return

            rafraichir_affichage()
            fltk.attente(0.15)
        
        #FIN DE L'ANIMATION
        fltk.attente(0.1)
        moteur.deplacer_dragons(donjon, aventurier, dragons)
        rafraichir_affichage()

    # Vérifier la victoire
    if statut == "victoire":
        fltk.texte(largeur_fenetre // 2, 20, "Victoire !", couleur="green", ancrage="center", taille=20)
        fltk.mise_a_jour()
        fltk.attente(2)
        retour_menu()
        return

    global indice
    indice = None
    effacer_intention()

def nouvelle_partie(fichier="donjons/donjon_niv1.txt"):
    """
    Démarre une nouvelle partie en chargeant un fichier de donjon.
    """
    global donjon, aventurier, dragons, bonus, intention, nb_lignes, nb_colonnes,donjon_indice,tresor,compteur_tresors
    moteur.tresor = []

    donjon, aventurier, dragons, bonus, tresors_charges, compteurs_charges = chargement_donjon.charger_donjon(fichier)

    # Propager le bonus et les trésors au moteur afin que la logique de jeu y ait accès
    try:
        moteur.tresor = tresors_charges
        compteur_tresors = compteurs_charges
        moteur.bonus = bonus
    except Exception:
        pass
    
    # Créer une copie du donjon de départ pour l'indice (indépendante des rotations du joueur)
    donjon_indice = []
    for ligne in donjon:
        nouvelle_ligne = []
        for salle in ligne:
            # on copie la salle pour ne pas partager les mêmes listes
            nouvelle_ligne.append(list(salle))
        donjon_indice.append(nouvelle_ligne)
    intention = []

    # Adapter l’affichage
    nb_lignes = len(donjon)
    nb_colonnes = len(donjon[0])
    mettre_a_jour_taille_case()
    rafraichir_affichage()

def programme_principal(fichier="donjons/donjon_niv1.txt"):
    """
    Boucle principale de l'interface graphique :
    - Crée la fenêtre
    - Lance une nouvelle partie
    - Gère les événements (clics, touches, redimensionnement, fermeture)
    """
    global largeur_fenetre, hauteur_fenetre,nb_lignes, nb_colonnes,tresor


    fltk.cree_fenetre(largeur_fenetre, hauteur_fenetre)
    nouvelle_partie(fichier)
    
 
    partie_en_cours = True
    while partie_en_cours:
        evenement = fltk.donne_ev()
        if evenement is None:
            fltk.mise_a_jour()
            continue

        type_ev = fltk.type_ev(evenement)
        
        # Gestion des événements de fermeture
        if type_ev == "Quitte":
            partie_en_cours = False
            fltk.ferme_fenetre()
            break
        elif type_ev == "Touche":
            touche = fltk.touche(evenement)
            if touche == "Escape":
                partie_en_cours = False
                fltk.ferme_fenetre()
                break
            
            elif touche in ("r", "R"):
                nouvelle_partie()
            
            elif touche in ("s", "S"):
                save_donjon()
                
            elif touche in ("i", "I"):
                global indice, donjon_indice
                indice = moteur.indice(donjon_indice, aventurier, dragons)
                rafraichir_affichage()

            elif touche in ("l", "L"):
                chargement_donjon.load_donjon()
                
            elif touche == "space":
                # Appel de la fonction pour appliquer le tour et obtenir le statut
                statut_fin = appliquer_intention()
                 
                
                # Vérification de la fin de partie
                if statut_fin is not None and (statut_fin[0] == "victoire" or statut_fin[0] == "defaite"):
                    partie_en_cours = False
                    fltk.mise_a_jour()
                    fltk.ferme_fenetre()
                    break
        
        # Gestion des autres événements
        elif type_ev == "Redimension":
            largeur_fenetre = fltk.largeur_fenetre()
            hauteur_fenetre = fltk.hauteur_fenetre()
            mettre_a_jour_taille_case()
            rafraichir_affichage()
        elif type_ev == "ClicGauche":
            x, y = fltk.abscisse(evenement), fltk.ordonnee(evenement)
            if x is not None and y is not None:
                case = obtenir_case_de_xy(int(x), int(y))
                pivoter_case(case)
        elif type_ev == "ClicDroit":
            souris_x = fltk.abscisse(evenement)
            souris_y = fltk.ordonnee(evenement)
            case = case_cliquee(souris_x, souris_y)
            if case:
                global compteur_tresors
                if compteur_tresors > 0 and moteur.placer_tresor(donjon, case, aventurier, dragons):
                    compteur_tresors -= 1
                    print("Trésor placé en", case)
                    rafraichir_affichage()
                else:
                    print("Impossible de placer un trésor ici.")

def case_cliquee(x, y):
    """
    Convertit les coordonnées pixel (x,y) en coordonnées de case [i,j],
    en tenant compte de la position réelle du donjon dans la fenêtre.
    """
    # coordonnées relatives au donjon
    x_rel = x - grille_x0
    y_rel = y - grille_y0

    # clic en dehors du rectangle du donjon
    if x_rel < 0 or y_rel < 0:
        return None

    j = x_rel // taille_case
    i = y_rel // taille_case

    if 0 <= i < nb_lignes and 0 <= j < nb_colonnes:
        return [i, j]
    return None


def save_donjon(fichier="sauvegarde.txt"):
    """
    Sauvegarde le donjon en texte EXACTEMENT comme un fichier de donjon.
    Très simple et lisible pour débutants.
    """
    global donjon, aventurier, dragons, compteur_tresors

    f = open(fichier, "w", encoding="utf-8")

    # 1. Grille
    for ligne in donjon:
        ligne_txt = "".join(chargement_donjon.salle_to_char(s) for s in ligne)
        f.write(ligne_txt + "\n")

    # 2. Aventurier
    coord, niv = aventurier[0], aventurier[1]
    f.write(f"A {coord[0]} {coord[1]} {niv}\n")

    # 3. Dragons
    for pos, niv in dragons:
        f.write(f"D {pos[0]} {pos[1]} {niv}\n")
    
    # 4. Bonus
    if bonus:
        for b in bonus:
            f.write(f"B {b[0]} {b[1]}\n")

    # On récupère la liste depuis le moteur
    for t_pos in moteur.tresor:
        f.write(f"T {t_pos[0]} {t_pos[1]}\n")

    f.write(f"P {compteur_tresors}\n")

    f.close()
    print("Partie sauvegardée avec succès (y compris les trésors) !")

def retour_menu():
    fltk.ferme_fenetre()
    os.system("python wall_is_you.py")


if __name__ == '__main__':
    programme_principal()
