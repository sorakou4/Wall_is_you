# Programme de conversion des caractères box-drawing en salles de donjon, pour la tache 3 du projet.

import interface
import moteur

def char_to_salle(c):
    """
    Convertit un caractère box-drawing en liste [H,D,B,G].
    Retourne une copie indépendante.
    """
    mapping = {
        '╬': [True, True, True, True],
        '╠': [True, True, True, False],
        '╣': [True, False, True, True],
        '╦': [False, True, True, True],
        '╩': [True, True, False, True],
        '╔': [False, True, True, False],
        '╗': [False, False, True, True],
        '╚': [True, True, False, False],
        '╝': [True, False, False, True],
        '═': [False, True, False, True],
        '║': [True, False, True, False],
        '╥': [True, False, False, False],
        '╨': [False, False, True, False],
        '╡': [False, True, False, False],
        '╞': [False, False, False, True],
    }
    return mapping[c]

def salle_to_char(s):
    """
    Convertit une salle [H, D, B, G] en caractère box-drawing.
    Les tuples sont obligatoires dans un dictionnaire.
    Mais prend bien en compte les listes en entrée.
    """
    mapping_inv = {
        (True, True, True, True): "╬",

        (True, True, True, False): "╠",
        (True, False, True, True): "╣",
        (False, True, True, True): "╦",
        (True, True, False, True): "╩",

        (False, True, True, False): "╔",
        (False, False, True, True): "╗",
        (True, True, False, False): "╚",
        (True, False, False, True): "╝",

        (False, True, False, True): "═",
        (True, False, True, False): "║",

        (True, False, False, False): "╥",
        (False, False, True, False): "╨",
        (False, True, False, False): "╡",
        (False, False, False, True): "╞",
    }

    return mapping_inv[tuple(s)]


def charger_donjon(fichier):
    """
    Lit un fichier .txt contenant un donjon Wall Is You.
    Renvoie le donjon, l'aventurier, les dragons, le bonus et les trésors.
    """
    f = open(fichier, "r", encoding="utf-8")
    lignes = [ligne.strip() for ligne in f]
    f.close()

    # Repérer la fin de la grille (début des entités A, D, B, T ou P)
    indice = 0
    # On ajoute "T" et "P" dans la condition d'arrêt
    while indice < len(lignes) and not (lignes[indice].startswith(("A", "D", "B", "T", "P"))):
        indice += 1

    grille = lignes[:indice]
    persos = lignes[indice:]

    # Construction du donjon
    donjon = []
    for ligne in grille:
        ligne_salles = [char_to_salle(c) for c in ligne]
        donjon.append(ligne_salles)

    aventurier = None
    dragons = []
    bonus = []
    tresors_poses = []      # Nouvelle liste pour les trésors sur la carte
    compteur_tresors = 4    # Valeur par défaut si non trouvée

    for l in persos:
        t = l.split()
        if not t: continue
        
        if t[0] == "A":
            li, co = int(t[1]), int(t[2])
            niv = int(t[3]) if len(t) >= 4 else 1
            aventurier = [[li, co], niv]

        elif t[0] == "D":
            li, co, niv = int(t[1]), int(t[2]), int(t[3])
            dragons.append([[li, co], niv])

        elif t[0] == "B":
            bonus.append([int(t[1]), int(t[2])])

        elif t[0] == "T": 
            tresors_poses.append([int(t[1]), int(t[2])])

        elif t[0] == "P": 
            compteur_tresors = int(t[1])

    return donjon, aventurier, dragons, bonus, tresors_poses, compteur_tresors

def load_donjon(fichier="sauvegarde.txt"):
    """
    Charge un donjon depuis fichier et met à jour les variables
    de l'interface en place, puis rafraîchit l'affichage.
    """
    # Charger les données depuis le fichier
    donjon_charge, aventurier_charge, dragons_charge, bonus_charge, tresors_charge, cpt_charge = charger_donjon(fichier)

    # Mise à jour Interface
    interface.donjon = donjon_charge
    interface.aventurier = aventurier_charge
    interface.dragons = dragons_charge
    interface.bonus = bonus_charge
    interface.compteur_tresors = cpt_charge

    # Mise à jour Moteur
    moteur.donjon = donjon_charge
    moteur.aventurier = aventurier_charge
    moteur.dragons = dragons_charge
    moteur.bonus = bonus_charge
    moteur.tresor = tresors_charge

    # Reset UI
    interface.intention = []
    interface.nb_lignes = len(interface.donjon)
    interface.nb_colonnes = len(interface.donjon[0]) if interface.nb_lignes > 0 else 0
    interface.mettre_a_jour_taille_case()
    interface.rafraichir_affichage()